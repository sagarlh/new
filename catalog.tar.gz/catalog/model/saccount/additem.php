<?php
class ModelSaccountAdditem extends Model {
	
	public function getcategory($parent_id = 0) {

       $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (c.category_id = cd.category_id) LEFT JOIN " . DB_PREFIX . "category_to_store c2s ON (c.category_id = c2s.category_id) WHERE c.parent_id = '" . (int)$parent_id . "' AND cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND c2s.store_id = '" . (int)$this->config->get('config_store_id') . "'  AND c.status = '1' AND is_fund=0 ORDER BY c.sort_order, LCASE(cd.name)");

		return $query->rows;	
    }
	
	
	public function getColourOption() {

       $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_description where name='Color'");
	   
	   $query_r = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value_description where option_id='".$query->row['option_id']."'");
	   
	   return $query_r->rows;	
    }
	
	public function getConditionOption() {

       $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_description where name='Condition'");
	   
	   $query_r = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value_description where option_id='".$query->row['option_id']."'");
	   
	   return $query_r->rows;	
    }
	
	public function addProduct($data){
		
		 $this->db->query("INSERT INTO " . DB_PREFIX . "product SET quantity = 1,minimum = 1, subtract = '0', 
		stock_status_id = '" . (int)$this->config->get('config_stock_status_id'). "',price='".(float)$data['price']."', 
		date_available = '" . date('Y-m-d', time() - 86400) . "',
		manufacturer_id = '" . (int)$data['manufacturer_id'] . "', 
		weight = '" . (float)$data['weight'] . "', 
		weight_class_id = '" . (int)$data['weight_class_id'] . "', 
		length = '" . (float)$data['length'] . "', 
		width = '" . (float)$data['width'] . "', 
		height = '" . (float)$data['height'] . "', 
		length_class_id = '" . (int)$data['length_class_id'] . "', 
		date_added = NOW(),status = 1,approve = 1,seller_id='".(int)$this->seller->getId()."'");
		
		$product_id = $this->db->getLastId();
		
		$this->db->query("INSERT INTO " . DB_PREFIX . "seller SET vproduct_id = '" . (int)$product_id . "', seller_id = '" . (int)$this->seller->getId() . "'");
		
		$this->db->query("INSERT INTO " . DB_PREFIX . "product_to_store SET product_id = '" . (int)$product_id . "', store_id = '0'");
		
		$this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category SET product_id = '" . (int)$product_id . "', category_id = '" . (int)$data['category_id'] . "'");
		
		$this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category SET product_id = '" . (int)$product_id . "', category_id = '" . (int)$data['sub_category_id'] . "'");
		
		$this->db->query("INSERT INTO " . DB_PREFIX . "product_description SET product_id = '" . (int)$product_id . "', name = '" . $this->db->escape($data['description']) . "', description = '" . $this->db->escape($data['description']) . "'");
		
	}
	
	public function getColourFilters(){
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "filter_description WHERE filter_group_id = '1'");

		return $query->rows;
	}
	
	public function getConditionFilters(){
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "filter_description WHERE filter_group_id = '2'");
		
		return $query->rows;
	}
	
	public function getProductFilters($product_id){
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_filter WHERE product_id = '" . (int)$product_id . "'");
		
		$data = array();
		if(!empty($query->rows)){
			foreach($query->rows as $rows){
				$data[] = $rows['filter_id'];
			}
		}
		return $data;
	}

	public function getFundProducts(){
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product WHERE is_fund = '1' AND seller_id = '0' AND status = '1' AND approve = '0' order by price");
		
		return $query->rows;
	}
	
	public function getSellerFundProducts(){
		$query = $this->db->query("SELECT p.product_id,s.seller_id,s.parent_product_id,p.status,p.approve FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "seller s ON ( p.product_id = s.vproduct_id ) WHERE p.is_fund = '1' AND p.seller_id = '" . (int)$this->seller->getId() . "'");
		$data = array();
		if(!empty($query)){
			foreach($query->rows aS $a){
				$data[] = $a['parent_product_id'];
			}
		}else{
			$data = array();
		}
			
		return $data;
	}
	
	public function getSellerFundTotal(){
		$query = $this->db->query("SELECT fund_total FROM " . DB_PREFIX . "sellers WHERE seller_id = '" . (int)$this->seller->getId() . "'");
		
		return $query->row['fund_total'];
	}
	
	
	public function getFundcategory($parent_id = 0) {

       $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (c.category_id = cd.category_id) LEFT JOIN " . DB_PREFIX . "category_to_store c2s ON (c.category_id = c2s.category_id) WHERE c.parent_id = '" . (int)$parent_id . "' AND cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND c2s.store_id = '" . (int)$this->config->get('config_store_id') . "'  AND c.status = '1' AND is_fund= '1' ORDER BY c.sort_order, LCASE(cd.name)");

		return $query->rows;	
    }
}

?>