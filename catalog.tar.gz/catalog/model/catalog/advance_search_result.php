 <?php
class ModelCatalogAdvanceSearchResult extends Model
{
    
    
    public function getFilterResult($data)
    {
		
        
        if ($data['search']==1) {
            $query = $this->db->query("SELECT DISTINCT sm.seller_id, sm.*,s.* FROM " . DB_PREFIX . "sellers s LEFT JOIN " . DB_PREFIX . "seller_market_name sm  ON (s.seller_id = sm.seller_id) left join " . DB_PREFIX . "seller_recurring sr on s.seller_id=sr.seller_id WHERE sm.market_name like '" . $data['search_market_name'] . "%'  and s.status = '1' and  s.approved = '1' AND sr.status=1");			
            return $query->rows;
        } elseif ($data['search']==2) {
            $query = $this->db->query("SELECT DISTINCT sm.seller_id, sm.*,s.* FROM " . DB_PREFIX . "sellers s LEFT JOIN " . DB_PREFIX . "seller_market_name sm  ON (s.seller_id = sm.seller_id) left join " . DB_PREFIX . "seller_recurring sr on s.seller_id=sr.seller_id  WHERE s.group_name like '" . $data['search_group_name'] . "%'  and s.status = '1' and  s.approved = '1'   AND sr.status=1");
			
            return $query->rows;
        } elseif ($data['search']==3) {
            $query = $this->db->query("SELECT DISTINCT sd.seller_id, sd.*,s.* FROM " . DB_PREFIX . "sellers s LEFT JOIN " . DB_PREFIX . "saddress sd  ON (s.seller_id = sd.seller_id) left join " . DB_PREFIX . "seller_recurring sr on s.seller_id=sr.seller_id  WHERE sd.postcode like '" . $data['search_zip_code'] . "%'  and  s.status = '1' and  s.approved = '1'  AND sr.status=1");
            return $query->rows;
        }
        
    }
    
    public function gettotal_items($id)
    {
        $query = $this->db->query("SELECT count(*) as total FROM " . DB_PREFIX . "product  WHERE seller_id = '" . (int)$id . "'  and status = 1 and quantity!=0");
        return $query->row['total'];
    }
	
	 public function getmarkets($data)
    {
        $sql="SELECT market_name FROM " . DB_PREFIX . "seller_market_name sm left join " . DB_PREFIX . "sellers s on sm.seller_id=s.seller_id  WHERE s.status=1 and  s.approved = 1 ";
		
		if (!empty($data['filter_name'])) {
				$sql .= " AND LCASE(sm.market_name) like '" . $this->db->escape(utf8_strtolower($data['filter_name'])) . "%'";				
			}
		
		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}
		
		$query = $this->db->query($sql);
		
        return $query->rows;
    }
	
	public function getgroups()
    {
        $sql="SELECT group_name FROM " . DB_PREFIX . "sellers  WHERE  status = 1 and approved=1 and group_name!=''";
		
		if (!empty($data['filter_name'])) {
				$sql .= " AND LCASE(group_name) like '" . $this->db->escape(utf8_strtolower($data['filter_name'])) . "%'";				
			}
		
		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}
		
		$query = $this->db->query($sql);

       return $query->rows;
    }
	
	public function getZipcode($data)
    {
        $sql="SELECT postcode FROM " . DB_PREFIX . "saddress sa left join " . DB_PREFIX . "sellers s on sa.seller_id=s.seller_id    WHERE  s.status = 1 and s.approved=1";
		
		if (!empty($data['filter_name'])) {
				$sql .= " AND LCASE(sa.postcode) like '" . $this->db->escape(utf8_strtolower($data['filter_name'])) . "%'";				
			}
		
		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}
		
		$query = $this->db->query($sql);
		
        return $query->rows;
    }
    
} 