<?php
class ControllerInformationCategory extends Controller {
	public function index() {
		$this->load->language('information/category');	

		$this->load->model('tool/image');
		

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('information/category')
		);

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_special'] = $this->language->get('text_special');
		$data['text_account'] = $this->language->get('text_account');
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_password'] = $this->language->get('text_password');
		$data['text_address'] = $this->language->get('text_address');
		$data['text_history'] = $this->language->get('text_history');
		$data['text_download'] = $this->language->get('text_download');
		$data['text_cart'] = $this->language->get('text_cart');
		$data['text_checkout'] = $this->language->get('text_checkout');
		$data['text_search'] = $this->language->get('text_search');
		$data['text_information'] = $this->language->get('text_information');
		$data['text_contact'] = $this->language->get('text_contact');

		$this->load->model('catalog/category');
		$this->load->model('catalog/product');

		$data['categories'] = array();

		$categories_1 = $this->model_catalog_category->getCategories(0);
		
		$this->load->model('catalog/funding');
        $this->load->model('tool/image');
        $data['recent_lists'] = array();
        $data['popular_lists'] = array();
        $data['social_lists'] = array();
        $recent_lists = $this->model_catalog_funding->getRecent(1);
        $recent_four = $this->model_catalog_funding->getRecentfour(1);
        if ($recent_four) {
            foreach ($recent_four as $recent_list) {
                   $query_seller_m = $this->db->query("SELECT *  FROM " . DB_PREFIX . "seller_market_name where seller_id='" . (int)$recent_list['seller_id'] . "'");
                //$target = $this->model_catalog_funding->getTarget($recent_list['seller_id']);
                //$raised = $this->model_catalog_funding->getRaised($recent_list['seller_id']);
               // $people = $this->model_catalog_funding->getPeople($recent_list['seller_id']);
                //;
                //$product_det = $this->model_catalog_product->getProduct(1);
                
                if ($recent_list['image'] && file_exists(DIR_IMAGE . $recent_list['image'])) {
                     //$image = $this->model_tool_image->resize($recent_list['image'], 236, 236);
                     $image =HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/' . $recent_list['image'].'&h=236&w=280';
                } else {
                    $image = $this->model_tool_image->resize('no_image.png', 236, 236);
                }
               // $percent = ( $raised > 0 ) ? ( $raised / $target ) * 100 : 0;
                $data['recent_four'][] = array(
                    'name' => isset($query_seller_m->row['market_name'])?$query_seller_m->row['market_name']:$recent_list['firstname'] . ' ' . $recent_list['lastname'],
                    'description' => html_entity_decode($recent_list['aboutus'], ENT_QUOTES, 'UTF-8'),
                    //'target' => $this->currency->format($target),
                    //'raised' => $this->currency->format($raised),
                    //'people' => $people,
                    'image' => $image,
                    //'percent' => $percent,
                    'link' => $this->url->link('product/seller', 'seller_id='.$recent_list['seller_id'], 'SSL')
                );
            }
        }
        $popular_lists = $this->model_catalog_funding->getPopularFour(1);
        if ($popular_lists) {
            foreach ($popular_lists as $popular_list) {
                  $query_seller_m = $this->db->query("SELECT *  FROM " . DB_PREFIX . "seller_market_name where seller_id='" . (int)$popular_list['seller_id'] . "'");
                //$target = $this->model_catalog_funding->getTarget($popular_list['seller_id']);
               // $raised = $this->model_catalog_funding->getRaised($popular_list['seller_id']);
                //$people = $this->model_catalog_funding->getPeople($popular_list['seller_id']);
                ;
                if ($popular_list['image'] && file_exists(DIR_IMAGE . $popular_list['image'])) {
                    //$image = $this->model_tool_image->resize($popular_list['image'], 236, 236);
					
					$image =HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/' . $popular_list['image'].'&h=236&w=280';
                } else {
                    $image = $this->model_tool_image->resize('no_image.png', 236, 236);
                }
                //$percent = ( $raised > 0 ) ? ( $raised / $target ) * 100 : 0;
                $data['popular_lists'][] = array(
                    'name' => isset($query_seller_m->row['market_name'])?$query_seller_m->row['market_name']:$popular_list['firstname'] . ' ' . $popular_list['lastname'],
                    'description' => html_entity_decode($popular_list['aboutus'], ENT_QUOTES, 'UTF-8'),
                    //'target' => $this->currency->format($target),
                   // 'raised' => $this->currency->format($raised),
                   // 'people' => $people,
                    'image' => $image,
                    //'percent' => $percent,
                    'link' => $this->url->link('product/seller', 'seller_id=' . $popular_list['seller_id'], 'SSL')
                );
            }
        }
        $social_lists = $this->model_catalog_funding->getPopularFour(1);
        if ($social_lists) {
            foreach ($social_lists as $social_list) {

                //$target = $this->model_catalog_funding->getTarget($social_list['seller_id']);
               // $raised = $this->model_catalog_funding->getRaised($social_list['seller_id']);
                //$people = $this->model_catalog_funding->getPeople($social_list['seller_id']);
                ;
                if ($social_list['image'] && file_exists(DIR_IMAGE . $social_list['image'])) {
                    $image = HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/' . $social_list['image'].'&h=236&w=280';
                } else {
                    $image = $this->model_tool_image->resize('no_image.png', 236, 280);
                }
               // $percent = ( $raised > 0 ) ? ( $raised / $target ) * 100 : 0;
                $data['social_lists'][] = array(
                    'name' => $social_list['firstname'] . ' ' . $social_list['lastname'],
                    'description' => html_entity_decode($social_list['aboutus'], ENT_QUOTES, 'UTF-8'),
                    //'target' => $this->currency->format($target),
                    //'raised' => $this->currency->format($raised),
                  //  'people' => $people,
                    'image' => $image,
                    //'percent' => $percent,
                    'link' => $this->url->link('product/seller', 'seller_id='.$social_list['seller_id'], 'SSL')
                );
            }
        }
		foreach ($categories_1 as $category_1) {
			$level_2_data = array();
			$level_2_data_other = array();

			$categories_2 = $this->model_catalog_category->getCategories($category_1['category_id']);

			foreach ($categories_2 as $category_2) {
				$level_3_data = array();

				$categories_3 = $this->model_catalog_category->getCategories($category_2['category_id']);

				foreach ($categories_3 as $category_3) {
					$level_3_data[] = array(
						'name' => $category_3['name'],
						'href' => $this->url->link('product/category', 'path=' . $category_1['category_id'] . '_' . $category_2['category_id'] . '_' . $category_3['category_id'],'SSL')
					);
				}
              if(strtolower($category_2['name'])!= "others"){
				$level_2_data[] = array(
					'name'     => $category_2['name'],
					'children' => $level_3_data,
					'href'     => $this->url->link('product/category', 'path=' . $category_1['category_id'] . '_' . $category_2['category_id'],'SSL')
				);
			  } else
			  {
				 $level_2_data_other[] = array(
					'name'     => $category_2['name'],
					'children' => $level_3_data,
					'href'     => $this->url->link('product/category', 'path=' . $category_1['category_id'] . '_' . $category_2['category_id'],'SSL')
				); 
			  }
			}
			
			if ($category_1['image']) {
				//$data['thumb'] = $this->model_tool_image->resize($category_1['image'], 270, 270);
				$data['thumb'] = HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/' . $category_1['image'].'&h=270&w=270';
			} else {
				$data['thumb'] = '';
			}

			$data['categories'][] = array(
				'name'     => $category_1['name'],
				'thumb' => $data['thumb'],
				'children' => $level_2_data,
				'children_other' => $level_2_data_other,
				'href'     => $this->url->link('product/category', 'path=' . $category_1['category_id'],'SSL')
			);
		}
		
		//print_r($data['categories']);

		$data['special'] = $this->url->link('product/special','','SSL');
		$data['account'] = $this->url->link('account/account', '', 'SSL');
		$data['edit'] = $this->url->link('account/edit', '', 'SSL');
		$data['password'] = $this->url->link('account/password', '', 'SSL');
		$data['address'] = $this->url->link('account/address', '', 'SSL');
		$data['history'] = $this->url->link('account/order', '', 'SSL');
		$data['download'] = $this->url->link('account/download', '', 'SSL');
		$data['cart'] = $this->url->link('checkout/cart','','SSL');
		$data['checkout'] = $this->url->link('checkout/checkout', '', 'SSL');
		$data['search'] = $this->url->link('product/search','','SSL');
		$data['contact'] = $this->url->link('information/contact','','SSL');

		$this->load->model('catalog/information');

		$data['informations'] = array();

		foreach ($this->model_catalog_information->getInformations() as $result) {
			$data['informations'][] = array(
				'title' => $result['title'],
				'href'  => $this->url->link('information/information', 'information_id=' . $result['information_id'],'SSL')
			);
		}

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/information/category.tpl')) {
			$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/information/category.tpl', $data));
		} else {
			$this->response->setOutput($this->load->view('default/template/information/category.tpl', $data));
		}
	}
}