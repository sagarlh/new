<?php
class ModelSaccountSeller extends Model {

public function getcommissions() {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "commission ORDER BY sort_order ASC");
		
		return $query->rows;
	}
	

public function updateexpirycusts(){
				
				$config_sellercommission_id = $this->config->get('config_sellercommission_id');
		if(!$config_sellercommission_id){
			$config_sellercommission_id = 1;
		}
				$this->db->query("UPDATE  `" . DB_PREFIX . "sellers` set commission_id = '" . (int)$config_sellercommission_id . "',
				expiry_date = '0000-00-00 00:00:00' WHERE
				commission_id !='".(int)$config_sellercommission_id."' AND expiry_date != '0000-00-00 00:00:00' AND expiry_date < NOW()");
			}
			  
			
			public function updatePlan($seller_id,$plan_id) {		
			$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "commission WHERE 	commission_id = '".(int)$plan_id."'");
			$durationid = $query->row['duration_id'];
			$days = $query->row['per'];
			$Date = date("Y-m-d H:i:s");
			$expirydate = "0000-00-00 00:00:00";
			if($durationid == 'd'){
				$expirydate = date('Y-m-d H:i:s', strtotime($Date. " + $days days"));
			}
			if($durationid == 'm'){
				$expirydate = date('Y-m-d H:i:s', strtotime($Date. " + $days months"));
			}
			if($durationid == 'y'){
				$expirydate = date('Y-m-d H:i:s', strtotime($Date. " + $days years"));
			}
			if($durationid == 'w'){
				$days = $days*7;
				$expirydate = date('Y-m-d H:i:s', strtotime($Date. " + $days days"));
			}

			$oldgroup_id = 0;
			$custquery = $this->db->query("select commission_id from " . DB_PREFIX . "sellers where seller_id = '".(int)$seller_id."'");
			if($custquery->row){
				$oldgroup_id = $custquery->row['commission_id'];
			}

			$this->db->query("INSERT INTO " . DB_PREFIX . "upgraded_members SET seller_id = '" . (int)$seller_id . "',
			old_commission_id = '" . (int)$oldgroup_id . "',
			commission_id = '" . (int)$plan_id . "', 
			amount = '" . (float)$query->row['amount'] . "', 
			upgrade_date = NOW(), expiry_date = '" . $expirydate. "', upgradedby = '".$seller_id."'");

			$this->db->query("UPDATE  " . DB_PREFIX . "sellers
			SET commission_id = '" . (int)$plan_id. "',
			expiry_date = '".$expirydate."',pay_status = 1
			WHERE seller_id = '" . (int)$seller_id . "'");
	}
	
	
	public function updateplanseller($data,$seller_id) {
		$this->db->query("UPDATE " . DB_PREFIX . "sellers SET commission_id = '" . (int)$data['commission_id'] . "'
		WHERE seller_id = '" . (int)$seller_id . "'");
	}

	
	public function addSeller($data) {
		$this->event->trigger('pre.seller.add', $data);
		$config_sellercommission_id = $this->config->get('config_sellercommission_id');
		if(!$config_sellercommission_id){
			$config_sellercommission_id = 1;
		}
		
		$folderName =  $data['username'];
		
		$path = HTTP_SERVER;
		
		$fPath = "image/" . $folderName;
		$fPath_p = $fPath.'/profile';
		$fPath_b = $fPath.'/billboard';
		$fPath_c = $fPath.'/product';
		$fPath_d = $fPath.'/video';
		$exist = is_dir($fPath);
		if(!$exist) {
		mkdir("$fPath");
		chmod("$fPath", 0777);
		mkdir("$fPath_p");
		chmod("$fPath_p", 0777);
		mkdir("$fPath_b");
		chmod("$fPath_b", 0777);
		mkdir("$fPath_c");
		chmod("$fPath_c", 0777);
		mkdir("$fPath_d");
		chmod("$fPath_d", 0777);
		}
		
		
      	$this->db->query("INSERT INTO " . DB_PREFIX . "sellers SET store_id = '" . (int)$this->config->get('config_store_id') . "',	username = '" . $this->db->escape($data['username']) . "', firstname = '" . $this->db->escape($data['firstname']) . "', lastname = '" . $this->db->escape($data['lastname']) . "', email = '" . $this->db->escape($data['email']) . "', salt = '" . $this->db->escape($salt = substr(md5(uniqid(rand(), true)), 0, 9)) . "',
		password = '" . $this->db->escape(sha1($salt . sha1($salt . sha1($data['password'])))) . "',     
		foldername = '" . $this->db->escape($data['username']) . "', 
		commission_id = '" . (int)$config_sellercommission_id . "', 
		ip = '" . $this->db->escape($this->request->server['REMOTE_ADDR']) . "', status = '1', seller_group_id = '" . (int)$data['seller_group_id'] . "', date_added = NOW()");
      	
		$seller_id = $this->db->getLastId();
		if ($data['username']) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "url_alias SET query = 'seller_id=" . (int)$seller_id . "', keyword = '" . $this->db->escape($data['username']) . "'");
			$this->db->query("INSERT INTO " . DB_PREFIX . "seller_market_name SET market_name = '" . $this->db->escape($data['username']) . "', seller_id = '" . (int)$seller_id . "'");
		}	
      	$this->db->query("INSERT INTO " . DB_PREFIX . "saddress SET seller_id = '" . (int)$seller_id . "', firstname = '" . $this->db->escape($data['firstname']) . "', lastname = '" . $this->db->escape($data['lastname']) . "'");
		
		$address_id = $this->db->getLastId();

      	$this->db->query("UPDATE " . DB_PREFIX . "sellers SET address_id = '" . (int)$address_id . "' WHERE seller_id = '" . (int)$seller_id . "'");
		
		$mail_template = $this->db->query("SELECT * FROM " . DB_PREFIX . "email WHERE type = 'signup'");
		
		$this->load->language('mail/seller');
		$subject = sprintf($this->language->get('text_subject'), $this->config->get('config_name'));
		$message = sprintf($this->language->get('text_welcome'), $this->config->get('config_name')) . "\n\n";
		$message .= $this->language->get('text_approval') . "\n";
		$message .= $this->url->link('saccount/login', '', 'SSL') . "\n\n";
		$message .= $this->language->get('text_services') . "\n\n";
		$message .= $this->language->get('text_thanks') . "\n";
		$message .= $this->config->get('config_name');

		$token = uniqid();
		
		$verification_link = $this->url->link('saccount/verify', 'token=' . $this->db->escape($token), 'SSL');
		
		$this->db->query("UPDATE " . DB_PREFIX . "sellers SET verification = '" . $this->db->escape($token) . "' WHERE seller_id = '" . (int)$seller_id . "'");
		
		$image = $this->config->get('config_url') . 'image/' .'Confirm-Email.png';
		
		$mail_message = '';
		$mail_message = $mail_template->row['message'];
		$mail_message = str_replace("{username}",$data['username'],$mail_message);
		$mail_message = str_replace("{email}",$data['email'],$mail_message);
		$mail_message = str_replace("{link}",$verification_link,$mail_message);
		$mail_message = str_replace("{image}",$image,$mail_message);
		
		$mail = new Mail();
		$mail->protocol = $this->config->get('config_mail_protocol');
		$mail->parameter = $this->config->get('config_mail_parameter');
		$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
		$mail->smtp_username = $this->config->get('config_mail_smtp_username');
		$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
		$mail->smtp_port = $this->config->get('config_mail_smtp_port');
		$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
		
		$data['content'] = html_entity_decode($mail_message, ENT_QUOTES, 'UTF-8');
		$data['title'] = $mail_template->row['subject'];
		$data['store_url'] = $this->config->get('config_url');
		$data['store_name'] = $this->config->get('config_name');
		$data['logo'] = $this->config->get('config_url') . 'image/' . $this->config->get('config_logo');
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/mail/blank_template.tpl')) {
			$html = $this->load->view($this->config->get('config_template') . '/template/mail/blank_template.tpl', $data);
		} else {
			$html = $this->load->view('default/template/mail/blank_template.tpl', $data);
		}

		$mail->setTo($data['email']);
		$mail->setFrom($this->config->get('config_email'));
		$mail->setSender($this->config->get('config_name'));
		$mail->setSubject($mail_template->row['subject']);
		$mail->setHtml($html);		
		$mail->send();
		
		// Send to main admin email if new account email is enabled
		if ($this->config->get('config_account_mail')) {
			$mail->setTo($this->config->get('config_email'));
			$mail->send();
			// Send to additional alert emails if new account email is enabled
			$emails = explode(',', $this->config->get('config_mail_alert'));
			foreach ($emails as $email) {
				if (utf8_strlen($email) > 0 && preg_match('/^[^\@]+@.*.[a-z]{2,15}$/i', $email)) {
					$mail->setTo($email);
					$mail->send();
				}
			}
		}

		$this->event->trigger('post.seller.add', $seller_id);
	}
	
	public function editSeller($data) {
		
		
		if(empty($data['password'])){		
		
		$this->db->query("UPDATE " . DB_PREFIX . "sellers SET firstname = '" . $this->db->escape($data['firstname']) . "', 
		lastname = '" . $this->db->escape($data['lastname']) . "', email = '" . $this->db->escape($data['email']) . "', 
		aboutus = '" . $this->db->escape($data['aboutus']). "',
		telephone = '" . $this->db->escape($data['telephone']) . "'	WHERE seller_id = '" . (int)$this->seller->getId() . "'");
		}else{
		$this->db->query("UPDATE " . DB_PREFIX . "sellers SET firstname = '" . $this->db->escape($data['firstname']) . "', 
		lastname = '" . $this->db->escape($data['lastname']) . "', email = '" . $this->db->escape($data['email']) . "', 
		aboutus = '" . $this->db->escape($data['aboutus']). "', salt = '" . $this->db->escape($salt = substr(md5(uniqid(rand(), true)), 0, 9)) . "',
		password = '" . $this->db->escape(sha1($salt . sha1($salt . sha1($data['password'])))) . "', 
		telephone = '" . $this->db->escape($data['telephone']) . "'	WHERE seller_id = '" . (int)$this->seller->getId() . "'");
		}
		
		$this->db->query("UPDATE " . DB_PREFIX . "saddress SET 	address_1 = '" . $this->db->escape($data['address_1']) . "', address_2 = '" . $this->db->escape($data['address_2']) . "', city = '" . $this->db->escape($data['city']) . "', postcode = '" . $this->db->escape($data['postcode']) . "',	 state = '" . $this->db->escape($data['state']) . "',	 country_id = '" . $this->db->escape($data['country_id']) . "', pickup_city = '" . $this->db->escape($data['pickup_city']) . "' , pickup_state = '" . $this->db->escape($data['pickup_state']) . "', pickup_country = '" . $this->db->escape($data['pickup_country']) . "', pick_up_address = '" . $this->db->escape($data['pick_up_address']) . "'	WHERE seller_id = '" . (int)$this->seller->getId() . "'");
		
		

		
	}

	public function editPassword($email, $password) {
      	$this->db->query("UPDATE " . DB_PREFIX . "sellers SET salt = '" . $this->db->escape($salt = substr(md5(uniqid(rand(), true)), 0, 9)) . "', password = '" . $this->db->escape(sha1($salt . sha1($salt . sha1($password)))) . "' WHERE email = '" . $this->db->escape($email) . "'");
	}

	public function editNewsletter($newsletter) {
		$this->db->query("UPDATE " . DB_PREFIX . "sellers SET newsletter = '" . (int)$newsletter . "' WHERE seller_id = '" . (int)$this->seller->getId() . "'");
	}
					
	public function getSeller($seller_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "sellers WHERE seller_id = '" . (int)$seller_id . "'");
		
		return $query->row;
	}
	
	public function getSellerByEmail($email) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "sellers WHERE email = '" . $this->db->escape($email) . "'");
		
		return $query->row;
	}
		
	public function getSellerByToken($token) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "sellers WHERE token = '" . $this->db->escape($token) . "' AND token != ''");
		
		$this->db->query("UPDATE " . DB_PREFIX . "sellers SET token = ''");
		
		return $query->row;
	}
		
	public function getSellers($data = array()) {
		$sql = "SELECT *, CONCAT(c.firstname, ' ', c.lastname) AS name, cg.name AS seller_group FROM " . DB_PREFIX . "sellers c LEFT JOIN " . DB_PREFIX . "seller_group cg ON (c.seller_group_id = cg.seller_group_id) ";

		$implode = array();
		
		if (isset($data['filter_name']) && !is_null($data['filter_name'])) {
			$implode[] = "LCASE(CONCAT(c.firstname, ' ', c.lastname)) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_name'])) . "%'";
		}
		
		if (isset($data['filter_email']) && !is_null($data['filter_email'])) {
			$implode[] = "c.email = '" . $this->db->escape($data['filter_email']) . "'";
		}
		
		if (isset($data['filter_seller_group_id']) && !is_null($data['filter_seller_group_id'])) {
			$implode[] = "cg.seller_group_id = '" . $this->db->escape($data['filter_seller_group_id']) . "'";
		}	
		
		if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
			$implode[] = "c.status = '" . (int)$data['filter_status'] . "'";
		}	
		
		if (isset($data['filter_approved']) && !is_null($data['filter_approved'])) {
			$implode[] = "c.approved = '" . (int)$data['filter_approved'] . "'";
		}	
			
		if (isset($data['filter_ip']) && !is_null($data['filter_ip'])) {
			$implode[] = "c.seller_id IN (SELECT seller_id FROM " . DB_PREFIX . "seller_ip WHERE ip = '" . $this->db->escape($data['filter_ip']) . "')";
		}	
				
		if (isset($data['filter_date_added']) && !is_null($data['filter_date_added'])) {
			$implode[] = "DATE(c.date_added) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
		}
		
		if ($implode) {
			$sql .= " WHERE " . implode(" AND ", $implode);
		}
		
		$sort_data = array(
			'name',
			'c.email',
			'seller_group',
			'c.status',
			'c.ip',
			'c.date_added'
		);	
			
		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];	
		} else {
			$sql .= " ORDER BY name";	
		}
			
		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}
		
		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}			

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}	
			
			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}		
		
		$query = $this->db->query($sql);
		
		return $query->rows;	
	}
		
	public function getTotalSellersByEmail($email) {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "sellers WHERE LOWER(email) = '" . $this->db->escape(strtolower($email)) . "'");
		
		return $query->row['total'];
	}

	public function getTotalSellersByUsername($username) {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "sellers WHERE LOWER(username) = '" . $this->db->escape(strtolower($username)) . "'");
		
		return $query->row['total'];
	}

	public function getSellerByUsername($username) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "sellers WHERE LOWER(username) = '" . $this->db->escape(strtolower($username)) . "'");
		
		return $query->row;
	}
	
	public function getIps($seller_id) {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "seller_ip` WHERE seller_id = '" . (int)$seller_id . "'");
		
		return $query->rows;
	}


public function getfoldername($seller_id) {
		$query = $this->db->query("SELECT foldername FROM `" . DB_PREFIX . "sellers` WHERE seller_id = '" . (int)$seller_id . "'");
		
		return $query->row['foldername'];
	}	
	
	public function isBlacklisted($ip) {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "seller_ip_blacklist` WHERE ip = '" . $this->db->escape($ip) . "'");
		
		return $query->num_rows;
	}	
	
	 public function getAddresses() {
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "saddress WHERE seller_id = '" . (int)$this->seller->getId() . "'");
	   
		
		return $query->row;
	 }

	public function editShippingPreference($data){
		
		if(!empty($data['shipping_service']) && !empty($data['zipcode'])){
			
			$this->db->query("DELETE FROM " . DB_PREFIX . "seller_shipping WHERE seller_id = '" . (int)$this->seller->getId() . "'");
			if( $data['shipping_preference'] == 2 ){
				$this->db->query("INSERT INTO " . DB_PREFIX . "seller_shipping SET seller_id = '" . (int)$this->seller->getId() . "', shipping_service = '" . $this->db->escape(json_encode($data['shipping_service'])) . "', zipcode = '" . $this->db->escape($data['zipcode']) . "', date_added = NOW()");
			}		
		}		
		
		$this->db->query("UPDATE " . DB_PREFIX . "sellers SET shipping_preference = '" . (int)$data['shipping_preference'] . "' WHERE seller_id = '" . (int)$this->seller->getId() . "'");
	}
	
	public function getShippingServide(){
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "seller_shipping WHERE seller_id = '" . (int)$this->seller->getId() . "'");
		return $query->row;
	}
	
	public function editProductShipping($data){
		if( $data['shipping_preference'] == 1 ){
			$this->db->query("UPDATE " . DB_PREFIX . "product SET shipping = '0' WHERE seller_id = '" . (int)$this->seller->getId() . "'");
		} else {
			$this->db->query("UPDATE " . DB_PREFIX . "product SET shipping = '1' WHERE seller_id = '" . (int)$this->seller->getId() . "'");
		}
	}
	
	public function update_pickup($data){
		$this->db->query("UPDATE " . DB_PREFIX . "saddress SET  pick_up_address = '" . $this->db->escape($data['pick_up_address']) . "' , pickup_city = '" . $this->db->escape($data['pickup_city']) . "' , pickup_state = '" . $this->db->escape($data['pickup_state']) . "', pickup_country = '" . $this->db->escape($data['pickup_country']) . "'	WHERE seller_id = '" . (int)$this->seller->getId() . "'");
	}
	
	 public function editSellerAboutUs($data) {	 
		
		$this->db->query("UPDATE " . DB_PREFIX . "sellers SET aboutus = '" . $this->db->escape($data). "'	WHERE seller_id = '" . (int)$this->seller->getId() . "'");
	 }
}
?>