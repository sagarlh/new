<?php
class ControllerCommonAdvanceSearch extends Controller {
	private $error = array();

	public function index() {
		
		$data=array();
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/common/advance_search.tpl')) {
			return $this->load->view($this->config->get('config_template') . '/template/common/advance_search.tpl', $data);
		} else {
			return $this->load->view('default/template/common/advance_search.tpl', $data);
		}
	}
   
}