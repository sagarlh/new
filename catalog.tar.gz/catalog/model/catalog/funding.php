<?php
class ModelCatalogFunding extends Model {
	public function getRecent($group_id) {
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "sellers s left join " . DB_PREFIX . "seller_recurring sr on s.seller_id=sr.seller_id WHERE s.seller_group_id = '". (int)$group_id ."' AND s.status = '1' AND s.approved = '1' AND sr.status=1  GROUP BY s.seller_id ORDER BY s.date_added DESC LIMIT 0,3");		
		return $query->rows;
	}

	public function getRecentfour($group_id) {
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "sellers s left join " . DB_PREFIX . "seller_recurring sr on s.seller_id=sr.seller_id WHERE s.seller_group_id = '". (int)$group_id ."' AND s.status = '1' AND s.approved = '1' AND sr.status=1  GROUP BY s.seller_id ORDER BY s.date_added DESC LIMIT 0,4");		
		return $query->rows;
	}

	public function getPopular($group_id) {
		$query = $this->db->query("SELECT ss.*, ( SELECT SUM(p.viewed) FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "seller s ON ( s.vproduct_id = p.product_id ) WHERE s.seller_id = ss.seller_id ) AS viewed FROM " . DB_PREFIX . "sellers ss  left join " . DB_PREFIX . "seller_recurring sr on ss.seller_id=sr.seller_id WHERE ss.seller_group_id = '". (int)$group_id ."' AND ss.status = '1' AND ss.approved = '1' AND sr.status=1 GROUP BY ss.seller_id ORDER BY viewed DESC LIMIT 3");

		return $query->rows;
	}

	public function getPopularFour($group_id) {
		$query = $this->db->query("SELECT ss.*, ( SELECT SUM(p.viewed) FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "seller s ON ( s.vproduct_id = p.product_id ) WHERE s.seller_id = ss.seller_id ) AS viewed FROM " . DB_PREFIX . "sellers ss  left join " . DB_PREFIX . "seller_recurring sr on ss.seller_id=sr.seller_id WHERE ss.seller_group_id = '". (int)$group_id ."' AND ss.status = '1' AND ss.approved = '1' AND sr.status=1 GROUP BY ss.seller_id ORDER BY viewed DESC LIMIT 4");

		return $query->rows;
	}

	public function getSociallist($group_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "sellers WHERE seller_group_id = '". (int)$group_id ."' AND status = '1' AND approved = '1' ORDER BY date_added DESC LIMIT 3");
		
		return $query->rows;
	}
	
	public function getTarget($seller_id) {
		$query = $this->db->query("SELECT fund_total FROM " . DB_PREFIX . "sellers WHERE seller_id = '" . (int)$seller_id . "'");
		
		return $query->row['fund_total'];
	}
	
	public function getRaised($seller_id){
		$sql = "SELECT SUM(op.seller_total) AS seller_amount, SUM(op.commission) AS commission, SUM(op.total) AS gross_amount, SUM(op.quantity) AS quantity FROM `" . DB_PREFIX . "order` o LEFT JOIN `" . DB_PREFIX . "order_product` op ON (o.order_id = op.order_id)";		
		$sql .= " WHERE o.order_status_id > '0'";
		$sql .= " AND op.seller_id = '" . $seller_id . "'";
		$query = $this->db->query($sql);
		
		if(!empty($query->row['gross_amount'])){
			return	$query->row['gross_amount'];
		} else {
			return 0;
		}
	}
	
	public function getPeople($seller_id){
		$sql = "SELECT o.customer_id,o.order_id FROM `" . DB_PREFIX . "order` o LEFT JOIN `" . DB_PREFIX . "order_product` op ON (o.order_id = op.order_id)";
		$sql .= " WHERE o.order_status_id > '0' AND op.seller_id = '" . (int)$seller_id . "' GROUP BY o.customer_id ";
		$query = $this->db->query($sql);
		
		if(!empty($query->rows)){
			return count($query->rows);
		} else {
			return 0;
		}
	}
}