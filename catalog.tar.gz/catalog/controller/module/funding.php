<?php
class ControllerModuleFunding extends Controller {
	public function index($setting) {
		static $module = 0;

		$this->load->model('saccount/funding');
		$this->load->model('catalog/funding');
		$this->load->model('tool/image');
		$data['seller_id'] = $setting['seller_id'];
		$query_seller_m = $this->db->query("SELECT *  FROM " . DB_PREFIX . "seller_market_name where seller_id='" . (int)$setting['seller_id'] . "' AND market_layout ='" . (int)$_GET['market_id'] . "'");
		$data['heading_title'] = $query_seller_m->row['market_name'];
		$data['folder_name'] = $setting['seller_info']['foldername'];
		$data['video'] = $this->model_saccount_funding->getFundingVideo($setting['seller_id']);
		$target = $this->model_catalog_funding->getTarget($setting['seller_id']);
		$raised = $this->model_catalog_funding->getRaised($setting['seller_id']);
		if(isset($data['video']['name'])){
		$data['video_path']= HTTPS_SERVER .'image/'. $setting['seller_info']['foldername'] . '/' . $data['video']['name'];
		}else{
			$data['video_path']='';
		}
		
		 if($data['seller_id']==$this->seller->getId()){
			$data['same_id']=1;
		} else {
			$data['same_id']=0;
		}	
		
		$data['logged'] = $this->seller->isLogged();
		
		$address = $this->db->query("SELECT * FROM " . DB_PREFIX . "saddress WHERE address_id = '" . (int)$setting['seller_info']['address_id'] . "'");
		
		if ( !empty($address->row['city']) && !empty($address->row['state']) ){
			$data['address'] = $address->row['city'].' ,'.$address->row['state'];
		} else {
			$data['address'] = '';
		}
		
	
	            
				$this->load->model('localisation/country');
		
    	        $country = $this->model_localisation_country->getCountry($address->row['country_id']);
				 $data['country'] = isset($country['name'])?$country['name']:'';	
		
		$data['text_loading'] = 'Loading';
		$data['button_cart'] = 'Fund Now';
		
		$data['description'] = html_entity_decode($setting['seller_info']['aboutus'], ENT_QUOTES, 'UTF-8');
		$data['target'] = $this->currency->format($target);
		$data['raised'] = $this->currency->format($raised);
		$data['people'] = $this->model_catalog_funding->getPeople($setting['seller_id']);
		$data['percent'] = ( $raised > 0 )? ( $raised / $target ) * 100 :0;
		
		$results = $this->model_saccount_funding->getFundingImages($setting['seller_id']);
		
		foreach ($results as $result) {
			
			$size = getimagesize(HTTPS_SERVER . 'image/' . $setting['seller_info']['foldername'].'/'.$result['name']);
			
			if($size[0] > $size[1] && $size[0] < 1200){
				
				$image_f= HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/' . $setting['seller_info']['foldername'].'/'.$result['name'].'&h=500&w=635&zc=2';
			}else if($size[0] < 1200){
				
				$image_f= HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/' . $setting['seller_info']['foldername'].'/'.$result['name'].'&h=500&w=635&zc=2';
			}
			else{
				$image_f= HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/' . $setting['seller_info']['foldername'].'/'.$result['name'].'&h=500&w=635&zc=2';
			}
			$data['images'][] = array(
				//'popup' => $this->model_tool_image->resize($setting['seller_info']['foldername'].'/'.$result['name'], $this->config->get('config_image_popup_width'), $this->config->get('config_image_popup_height')),
				'popup' => HTTPS_SERVER . 'timthumb.php?src='.HTTPS_SERVER . 'image/' . $setting['seller_info']['foldername'].'/'.$result['name'].'&h=900&w=1200&zc=2',
				//'thumb' => $this->model_tool_image->resize($setting['seller_info']['foldername'].'/'.$result['name'], 500, 250)
				'thumb' => $image_f
				
			);
		}
		
		$data['module'] = $module++;
		
		$this->document->addStyle('catalog/view/javascript/jquery/magnific/magnific-popup.css');
		$this->document->addStyle('catalog/view/javascript/jquery/owl-carousel/owl.carousel.css');
		$this->document->addStyle('catalog/view/javascript/jquery/prettyPhoto/prettyPhoto.css');
		$this->document->addScript('catalog/view/javascript/jquery/magnific/jquery.magnific-popup.min.js');		
		$this->document->addScript('catalog/view/javascript/jquery/owl-carousel/owl.carousel.min.js');
		$this->document->addScript('catalog/view/javascript/jquery/prettyPhoto/jquery.prettyPhoto.js');
			
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/funding.tpl')) {
			return $this->load->view($this->config->get('config_template') . '/template/module/funding.tpl', $data);
		} else {
			return $this->load->view('default/template/module/funding.tpl', $data);
		}
	}
}