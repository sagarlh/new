var successCount=0;
var errorCount=0;
$(function () {
    'use strict';

    // Initialize the jQuery File Upload widget:
    //$('.secondSection').show();
    $('#fileupload').fileupload({
        url: baseUrl+'/upload/uploadfile',
        autoUpload: true,
        acceptFileTypes:/(\.|\/)(mov|mp4|wmv|3gp|flv)$/i,
        dropZone:$('.dropHereSection')
    }).on('fileuploadprocessalways', function (e, data) {
        var currentFile = data.files[data.index];
        if (data.files.error && currentFile.error) {
          // there was an error, do something about it
          $('#videoExtError').html('You have selected wrong extension.').show();
          $('.files').html('');
        }else{
            $('#videoExtError').html('').hide();
            $('.firstSection').hide();
            $('.secondSection').show();
        }
         $('.drapDropSec').css('background-color','');
     });
    $('#fileupload').bind('fileuploadcompleted', function (e, data) {
        var response = jQuery.parseJSON( data.jqXHR.responseText );
        var error = response.files[0].error;
        $('.titleSection').show();
        if(error){
            errorCount++;
            if(errorCount>1){
             $('#failededUpload').html(errorCount+' files');
            }else{
              $('#failededUpload').html(errorCount+' file');
            }
        }else{
            successCount++;
            if(successCount>1){
             $('#completedUpload').html(successCount+' files');
           }else{
              $('#completedUpload').html(successCount+' file');
           }
           var fileName=response.files[0].name;
           var actualfileName=response.files[0].actual_name;
           var duration=response.files[0].duration;
           jQuery.ajax({
                type:'post',
                url:baseUrl+'/upload/savefile/'+fileName+'/'+actualfileName+'/'+duration,
                success:function(responseText){
                    var result=responseText.split('@');
                    $('.formattedFilename').each(function(){
                        var fileName=$.trim($(this).html());
                        if(fileName==result[0]){
                            $(this).parent().find('.editVid').attr('href',baseUrl+'/video/edit/'+result[1]);
                            $(this).parent().parent().find('.deleteVid').attr('vid-id',result[1]);
                            $(this).parent().parent().find('.viewVid').attr('href',baseUrl+'/play/index/'+result[1]);
                        }
                    });
                }
           });
        }
    });
    $('#fileupload').bind('fileuploaddragover', function (e, data) {
        $('.drapDropSec').css('background-color','#c7effa');
    });
    $('.drapDropSec').on('dragleave', function (e) {
        $('.drapDropSec').css('background-color','');
    });
    $('body').on('click','.deleteVid',function(){
        var vidId=$(this).attr('vid-id');
        if(vidId!=''){
            var delSec=this;
            var confirmAttr=confirm('Are you sure?');
            if(confirmAttr){
               jQuery.ajax({
                    url:baseUrl+'/video/delete/'+vidId,
                    success:function(responseText){
                       $(delSec).parent().parent().remove();
                    }
               });  
            }
        }
    });
});
$(document).ready(function(){
    $('#selectFileFromDevice').click(function(){
        $('#multipleFile').trigger('click');
    });
    $( document ).ajaxStop(function() {
       $('.thirdSection').show();
       $('.uploadedTitle').show();
       $('.uploadingTitle').hide();
    });

});