<?php
class ControllerCommonPaymentAdaptive extends Controller {
	public function index() {
		echo "tetstt";
		$paypalUrl="https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_ap-payment&paykey=";
		$createPacket = array(
				"actionType"=>"PAY",
				"currencyCode"=>"USD",
				"receiverList"=> array(
					"receiver" => array(
						array(
							"amount" => 1,
							"email" => 'abcd@gmail.com'
						),
						 array(
							"amount" => 2,
							"email" => 'abcd1@gmail.com'
						)
					)
				),
				"returnUrl" => "http://www.synapse.asia/skadco8187/upload/index.php?route=common/payment_adaptive",
				"cancelUrl" => "http://www.synapse.asia/skadco8187/upload/index.php?route=common/payment_adaptive",
				//"ipnNotificationUrl" =>$this->config['package_pay_IPN'],
				"memo"=>'To complete your reservation you will need to pay a 50% deposit on the package you selected.',
				"requestEnvelope"=> array(
					"errorLanguage"=>"en_US",    // Language used to display errors
					"detailLevel"=>"ReturnAll"
				)
			);
             //print_r($createPacket);
			$response = $this->paypalSend($createPacket, "Pay");
			
			$payKey = $response['payKey'];
			echo $paypalUrl.$payKey;
			//header('Location: '.$paypalUrl.$payKey);
		
		   
	}
	
	
	public function paypalSend($data,$call){
		


		    $apiUrl ="https://svcs.sandbox.paypal.com/AdaptivePayments/";
		
			$paypal_user_id	= 'coolteam5731-facilitator_api1.gmail.com';
			$paypal_pass	= 'ZG7APNXRBJSKYKQ9';
			$paypal_user_signature	=	'AFcWxV21C7fd0v3bYYYRCpSSRl31AaaE2EWsueGLkt3CIGjvHMMfziKU';
			$paypal_app_id	=	'APP-80W284485P519543T';
			
			$headers = array(
			"X-PAYPAL-SECURITY-USERID : ".$paypal_user_id,
			"X-PAYPAL-SECURITY-PASSWORD : ".$paypal_pass,
			"X-PAYPAL-SECURITY-SIGNATURE : ".$paypal_user_signature,
			"X-PAYPAL-APPLICATION-ID : ".$paypal_app_id,
			"X-PAYPAL-REQUEST-DATA-FORMAT : JSON",
			"X-PAYPAL-RESPONSE-DATA-FORMAT : JSON"
		);
		//echo $apiUrl.$call;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL , $apiUrl.$call);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSLVERSION , 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_exec($ch);
		return json_decode(curl_exec($ch),true);
		if(curl_errno($ch))
       echo 'Curl error: '.curl_error($ch);
		   
				
		
	}
	
	public function check_pay_email(){
		
		$apiUrl='https://svcs.sandbox.paypal.com/AdaptiveAccounts/GetVerifiedStatus';
		
		$nvpStr = 'emailAddress=dsbhadauria@sampatti.com';
		
		$detailLevel    = urlencode("ReturnAll");   // See DetailLevelCode in the WSDL for valid enumerations
$errorLanguage  = urlencode("en_US");       // This should be the standard RFC 3066 language identification tag, e.g., en_US
//$nvpreq = "requestEnvelope.errorLanguage=$errorLanguage&requestEnvelope.detailLevel=$detailLevel";
$nvpreq= "$nvpStr";
		
			$paypal_user_id	= 'coolteam5731-facilitator_api1.gmail.com';
			$paypal_pass	= 'ZG7APNXRBJSKYKQ9';
			$paypal_user_signature	=	'AFcWxV21C7fd0v3bYYYRCpSSRl31AaaE2EWsueGLkt3CIGjvHMMfziKU';
			$paypal_app_id	=	'APP-80W284485P519543T';
			
			$headers = array(
			"X-PAYPAL-SECURITY-USERID : ".$paypal_user_id,
			"X-PAYPAL-SECURITY-PASSWORD : ".$paypal_pass,
			"X-PAYPAL-SECURITY-SIGNATURE : ".$paypal_user_signature,
			"X-PAYPAL-APPLICATION-ID : ".$paypal_app_id,
			"X-PAYPAL-REQUEST-DATA-FORMAT : JSON",
			"X-PAYPAL-RESPONSE-DATA-FORMAT : JSON"
		);
		$data = 'abc';
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL , $apiUrl);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSLVERSION , 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $nvpreq);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$resp = json_decode(curl_exec($ch),true);
		
		if(curl_errno($ch)){
			 echo 'Curl error: '.curl_error($ch);
		}
        
		echo '<pre>rtyrt';print_r($resp);die;
	}
}