<?php
 error_reporting(E_ALL);
ini_set('display_errors', '1'); 
class ControllerSaccountEmail extends Controller {  
	public function index() { 
		
		if (!$this->seller->isLogged()) {
	  		$this->response->redirect($this->url->link('common/home', '', 'SSL'));
    	}
		
		$this->language->load('saccount/email');
		$this->document->setTitle($this->language->get('heading_title'));
		
		$data['breadcrumbs'] = array();

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home'),     	
        	'separator' => false
      	); 

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_account'),
			'href'      => $this->url->link('saccount/account', '', 'SSL')
      	);

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_shipping'),
			'href'      => $this->url->link('saccount/email', '', 'SSL')
      	);
		
		$data['seller_id'] = $this->seller->getId();
		$this->load->model('saccount/seller');
		$data['folder_name'] = $this->model_saccount_seller->getfoldername($this->seller->getId());
		$this->load->model('catalog/review');
		
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		$data['emails'] = array();

		$review_total = $this->model_catalog_review->getTotalMailsBySellerId($this->seller->getId());

		$results = $this->model_catalog_review->getMailsBySellerId($this->seller->getId(), ($page - 1) * 5, 5);

		foreach ($results as $result) {
			$content = json_decode($result['content']);
			$data['emails'][] = array(
				'id'     => $result['id'],
				'href'     => $this->url->link('saccount/email/view', 'email_id='.$result['id'], 'SSL'),
				'content'       => html_entity_decode($content->subject,ENT_QUOTES,'utf-8'),
				'read_status'       => ( empty($result['read_status']) || $result['read_status'] == 0 )?'Unread':'Read',
				'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added']))
			);
		}

		$pagination = new Pagination();
		$pagination->total = $review_total;
		$pagination->page = $page;
		$pagination->limit = 5;
		$pagination->url = $this->url->link('saccount/email', 'page={page}','SSL');

		$data['pagination'] = $pagination->render();
		$data['page'] = $page;
		$data['limit'] = 5;
		
		$data['results'] = sprintf($this->language->get('text_pagination'), ($review_total) ? (($page - 1) * 5) + 1 : 0, ((($page - 1) * 5) > ($review_total - 5)) ? $review_total : ((($page - 1) * 5) + 5), $review_total, ceil($review_total / 5));
		
		$data['text_list'] = $this->language->get('text_list');
		$data['text_shipping'] = $this->language->get('text_shipping');
		$data['entry_pick'] = $this->language->get('entry_pick');
		$data['entry_delivery'] = $this->language->get('entry_delivery');
		$data['entry_seller'] = $this->language->get('entry_seller');
		
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_update'] = $this->language->get('button_update');
		
		$data['back'] = $this->url->link('saccount/account', '', 'SSL');
		$data['logged'] = $this->seller->isLogged();

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$data['seller_right'] = $this->load->controller('product/seller_right');
		$data['seller_add_item'] = $this->load->controller('product/seller_add_item');
		$data['seller_profile'] = $this->load->controller('product/seller_profile');
		$data['seller_billboard'] = $this->load->controller('product/seller_billboard');
		$data['seller_marketplace'] = $this->load->controller('product/seller_marketplace');
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/saccount/email.tpl')) {
			$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/saccount/email.tpl', $data));
		} else {
			$this->response->setOutput($this->load->view('default/template/saccount/email.tpl', $data));
		}	   
	}
	
	public function view() { 
		
		if (!$this->seller->isLogged()) {
	  		$this->response->redirect($this->url->link('common/home', '', 'SSL'));
    	}
		
		$this->language->load('saccount/email');
		$this->document->setTitle($this->language->get('heading_title'));
		
		$data['breadcrumbs'] = array();

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home'),     	
        	'separator' => false
      	); 

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_account'),
			'href'      => $this->url->link('saccount/account', '', 'SSL')
      	);

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_shipping'),
			'href'      => $this->url->link('saccount/email', '', 'SSL')
      	);
		
		$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('View'),
			'href'      => $this->url->link('saccount/email/view', 'email_id='.$this->request->get['email_id'], 'SSL')
      	);
		
		$data['seller_id'] = $this->seller->getId();
		$this->load->model('saccount/seller');
		$data['folder_name'] = $this->model_saccount_seller->getfoldername($this->seller->getId());
		$this->load->model('catalog/review');
		
		$data['email'] = $this->model_catalog_review->getMailByEmailId($this->request->get['email_id']);

		$data['text_list'] = $this->language->get('text_list');
		$data['text_shipping'] = $this->language->get('text_shipping');
		$data['entry_pick'] = $this->language->get('entry_pick');
		$data['entry_delivery'] = $this->language->get('entry_delivery');
		$data['entry_seller'] = $this->language->get('entry_seller');
		
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_update'] = $this->language->get('button_update');
		
		$data['back'] = $this->url->link('saccount/email', '', 'SSL');
		$data['logged'] = $this->seller->isLogged();

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$data['seller_right'] = $this->load->controller('product/seller_right');
		$data['seller_add_item'] = $this->load->controller('product/seller_add_item');
		$data['seller_profile'] = $this->load->controller('product/seller_profile');
		$data['seller_billboard'] = $this->load->controller('product/seller_billboard');
		$data['seller_marketplace'] = $this->load->controller('product/seller_marketplace');
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/saccount/view_email.tpl')) {
			$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/saccount/view_email.tpl', $data));
		} else {
			$this->response->setOutput($this->load->view('default/template/saccount/view_email.tpl', $data));
		}	   
	}	
}
?>